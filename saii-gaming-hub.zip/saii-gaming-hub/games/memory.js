export default function({box,run,score,over,sfx}){
 const E=['🚀','👾','🎮','⚡','🔥','💎','🎯','🛸'],d=[...E,...E];
 for(let i=15;i>0;i--){const j=Math.random()*(i+1)|0;[d[i],d[j]]=[d[j],d[i]]}
 const el=document.createElement('div');el.className='mem';
 const info=document.createElement('p');info.className='hint';info.textContent='Moves 0';
 let open=[],lock=false,moves=0,found=0;const t0=Date.now();
 const bs=d.map((_,i)=>{const b=document.createElement('button');b.setAttribute('aria-label','Card '+(i+1));run.on(b,'click',()=>flip(i));el.append(b);return b});
 box.append(el,info);
 const flip=i=>{const b=bs[i];if(lock||b.classList.contains('up'))return;
  b.classList.add('up');b.textContent=d[i];sfx(440);open.push(i);if(open.length<2)return;
  moves++;info.textContent='Moves '+moves;const[a,c]=open;open=[];
  if(d[a]===d[c]){found++;sfx(760);bs[a].classList.add('ok');bs[c].classList.add('ok');
   if(found===8){const s=Math.max(10,500-moves*15-Math.round((Date.now()-t0)/1000)*2);score(s);run.after(600,()=>over(s,{won:true}))}}
  else{lock=true;run.after(700,()=>{[a,c].forEach(k=>{bs[k].classList.remove('up');bs[k].textContent=''});lock=false})}};
 return{start(){score(0)}};
}
