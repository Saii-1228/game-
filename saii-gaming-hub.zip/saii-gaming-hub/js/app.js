import * as S from './store.js';
import {beep} from './sound.js';
import {runner} from './engine.js';
import {GAMES,CATS} from './games.js';

const $=s=>document.querySelector(s),view=$('#view'),db=S.get;
const esc=s=>String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const byId=id=>GAMES.find(g=>g.id===id),best=id=>db().scores[id]||0;
const lvl=xp=>{let l=1;while(xp>=25*l*(l+3))l++;return l};
const xpInfo=()=>{const x=db().player.xp,l=lvl(x),a=25*(l-1)*(l+2),b=25*l*(l+3);return{x,l,p:Math.round((x-a)/(b-a)*100)}};

const ACH=[
['first','First Game','Play your first game',c=>c.n>=1],
['five','Arcade Beginner','Play 5 games',c=>c.n>=5],
['addict','Arcade Addict','Play 25 games',c=>c.n>=25],
['record','High Score','Set your first personal record',c=>c.rec],
['speed','Speed Demon','Average under 300 ms in Reaction Test',c=>c.id==='reaction'&&c.extra.avg<300],
['mem','Memory Master','Complete Memory Match',c=>c.id==='memory'&&c.extra.won],
['win','Outsmarted','Beat the computer at Tic Tac Toe',c=>c.id==='ttt'&&c.extra.won],
['explorer','Game Explorer','Play games from 3 categories',c=>c.cats>=3],
['fav','Collector','Favorite 3 games',()=>db().favs.length>=3],
['legend','Legend','Reach level 5',()=>lvl(db().player.xp)>=5]];
function toast(m){const t=document.createElement('div');t.className='toast';t.textContent=m;$('#toast').append(t);setTimeout(()=>t.remove(),3200)}
function check(c){for(const[id,n,,f]of ACH)if(!db().ach.includes(id)&&f(c)){db().ach.push(id);db().player.xp+=50;toast('🏆 '+n+' unlocked  +50 XP');beep(900,.2)}S.save()}

let t0=0;
function finish(id,score,extra={}){const d=db(),rec=score>best(id);
 d.plays[id]=(d.plays[id]||0)+1;d.total++;if(rec)d.scores[id]=score;
 d.history=[id,...d.history.filter(x=>x!==id)].slice(0,12);
 d.player.xp+=10+Math.min(50,score/10|0);d.time+=Math.round((Date.now()-t0)/1000);
 const cats=new Set(Object.keys(d.plays).map(k=>byId(k)?.cat)).size;
 check({n:d.total,rec:rec&&score>0,id,extra,cats});return rec&&score>0}

const card=g=>{const f=db().favs.includes(g.id);
 return`<article class="card" style="--h:${g.hue}"><a class="art" href="#/game/${g.id}" aria-label="${g.title} details">${g.ico}</a><div class="ci"><h3>${g.title}</h3><p class="meta">${g.cat}, ${g.diff}, ${g.time}</p><p class="meta">Best ${best(g.id)}</p><div class="row"><a class="btn sm" href="#/play/${g.id}">Play</a><button class="fav${f?' on':''}" data-a="fav" data-id="${g.id}" aria-pressed="${f}" aria-label="Favorite ${g.title}">♥</button></div></div></article>`};
const row=(t,gs,empty)=>!gs.length&&!empty?'':`<section><h2>${t}</h2>${gs.length?`<div class="hrow">${gs.map(card).join('')}</div>`:`<p class="empty">${empty}</p>`}</section>`;
const stat=(l,v)=>`<div class="stat"><b>${v}</b><span>${l}</span></div>`;

const V={};
V.home=()=>{const d=db(),u=xpInfo(),rec=d.history.map(byId).filter(Boolean);
 view.innerHTML=`<section class="hero"><h1>SAII GAMING HUB</h1><p>Play. Compete. Level Up.</p><div class="row"><a class="btn" href="#/play/${rec[0]?.id||'snake'}">Play now</a><a class="btn ghost" href="#/games">Browse games</a></div><div class="who"><b>${esc(d.player.name)}</b> Level ${u.l}<div class="xp"><i style="width:${u.p}%"></i></div><small>${u.x} XP</small></div></section>
 ${row('Recently played',rec,'')}${row('Featured games',GAMES,'')}${row('Your favorites',d.favs.map(byId).filter(Boolean),'Tap ♥ on a game to keep it here.')}
 <section><h2>Player stats</h2><div class="stats">${stat('Games played',d.total)}${stat('Total XP',u.x)}${stat('Achievements',d.ach.length+'/'+ACH.length)}</div></section>`};
let q='',cat='All',sort='pop';
const rank=g=>{const i=db().history.indexOf(g.id);return i<0?99:i};
const SORT={pop:(a,b)=>(db().plays[b.id]||0)-(db().plays[a.id]||0),az:(a,b)=>a.title.localeCompare(b.title),score:(a,b)=>best(b.id)-best(a.id),recent:(a,b)=>rank(a)-rank(b)};
const fill=()=>{const k=q.toLowerCase(),l=GAMES.filter(g=>(cat==='All'||g.cat===cat)&&(g.title+g.cat+g.desc+g.tags).toLowerCase().includes(k)).sort(SORT[sort]);
 $('#grid').innerHTML=l.map(card).join('')||'<p class="empty">No games match. Try another word or category.</p>'};
V.games=()=>{view.innerHTML=`<h2>Games</h2><div class="tools"><input id="q" type="search" placeholder="Search games" aria-label="Search games" value="${esc(q)}"><select id="so" aria-label="Sort games">${[['pop','Most played'],['az','A to Z'],['score','Highest score'],['recent','Recently played']].map(([k,l])=>`<option value="${k}"${k===sort?' selected':''}>${l}</option>`).join('')}</select></div><div class="chips">${['All',...CATS].map(c=>`<button class="chip${c===cat?' on':''}" data-a="cat" data-id="${c}">${c}</button>`).join('')}</div><div id="grid" class="grid"></div>`;fill()};
V.favs=()=>{const l=db().favs.map(byId).filter(Boolean);view.innerHTML=`<h2>Favorites (${l.length})</h2>${l.length?`<div class="grid">${l.map(card).join('')}</div>`:'<p class="empty">No favorites yet. Tap ♥ on any game.</p>'}`};
V.ach=()=>{const a=db().ach;view.innerHTML=`<h2>Achievements ${a.length}/${ACH.length}</h2><div class="list">${ACH.map(([id,n,d])=>`<div class="ach${a.includes(id)?' on':''}"><span aria-hidden="true">${a.includes(id)?'🏆':'🔒'}</span><div><b>${n}</b><br><small>${d}. Reward: 50 XP</small></div></div>`).join('')}</div>`};
V.me=()=>{const d=db(),u=xpInfo();
 view.innerHTML=`<section class="hero"><div class="avatar" aria-hidden="true">${esc(d.player.name[0]||'S').toUpperCase()}</div><h1>${esc(d.player.name)}</h1><div class="who">Level ${u.l}<div class="xp"><i style="width:${u.p}%"></i></div><small>${u.x} XP</small></div></section>
 <div class="stats">${stat('Games played',d.total)}${stat('Play time',Math.round(d.time/60)+' min')}${stat('Achievements',d.ach.length+'/'+ACH.length)}${stat('Favorites',d.favs.length)}</div>
 <h2>Personal records</h2><p class="meta">Local scores: saved on this device only, not a global leaderboard.</p>
 <div class="list">${[...GAMES].sort((a,b)=>best(b.id)-best(a.id)).map(g=>`<a class="ach" href="#/game/${g.id}"><span aria-hidden="true">${g.ico}</span><div><b>${g.title}</b><br><small>Best ${best(g.id)}, played ${db().plays[g.id]||0} times</small></div></a>`).join('')}</div>`};
V.set=()=>{const s=db().settings;
 view.innerHTML=`<h2>Settings</h2><div class="panel"><label class="sw">Sound effects<input type="checkbox" data-a="tog" data-id="sound"${s.sound?' checked':''}></label><label class="sw">Animations<input type="checkbox" data-a="tog" data-id="motion"${s.motion?' checked':''}></label>
 <label>Gamer name<input id="nm" maxlength="16" value="${esc(db().player.name)}"></label><button class="btn sm" data-a="name">Save name</button></div>
 <h2>Data</h2><div class="panel"><button class="btn ghost" data-a="wipe" data-id="favs">Clear favorites</button> <button class="btn ghost" data-a="wipe" data-id="history">Clear history</button> <button class="btn danger" data-a="wipe" data-id="all">Reset all data</button></div>
 <h2>About</h2><p class="meta">SAII GAMING HUB v1.0.0. Made by Saii (github.com/saii-1228). Saved locally in your browser.</p>`};
V.game=id=>{const g=byId(id);if(!g)return void(location.hash='#/games');const f=db().favs.includes(id);
 view.innerHTML=`<a class="back" href="#/games">← Back</a><div class="art lg" style="--h:${g.hue}" role="img" aria-label="${g.title} artwork">${g.ico}</div><h1>${g.title}</h1><p class="meta">${g.cat}, ${g.diff}, about ${g.time}</p><p>${g.desc}</p><h2>Controls</h2><p>${g.how}</p><p class="meta">Best ${best(id)}, played ${db().plays[id]||0} times</p>
 <div class="row"><a class="btn" href="#/play/${id}">Play</a><button class="fav${f?' on':''}" data-a="fav" data-id="${id}" aria-pressed="${f}" aria-label="Favorite">♥</button></div>${row('Related',GAMES.filter(x=>x.cat===g.cat&&x.id!==id),'')||row('More games',GAMES.filter(x=>x.id!==id),'')}`};

let cur=null;
const stopGame=()=>{if(cur){clearTimeout(cur.cd);cur.run?.destroy();cur=null}};
V.play=id=>{const g=byId(id);if(!g)return void(location.hash='#/games');
 view.innerHTML=`<section class="play" aria-label="${g.title}"><header class="bar"><a class="ib" href="#/game/${id}" aria-label="Exit game">✕</a><strong>${g.title}</strong><span>Score <b id="sc">0</b></span><span>Best <b id="bs">${best(id)}</b></span><button class="ib" data-a="pause" aria-label="Pause">❚❚</button><button class="ib" data-a="restart" aria-label="Restart">↻</button><button class="ib" data-a="fs" aria-label="Fullscreen">⛶</button><button class="ib" data-a="snd" aria-label="Toggle sound">♪</button></header><div class="stage"><div id="box"></div><div id="ov" class="ov"></div></div></section>`;
 const box=$('#box'),ov=$('#ov'),st=cur={run:null,cd:0,paused:false,live:false};
 const say=h=>{ov.innerHTML=h;ov.hidden=!h};
 const fail=e=>{console.error(e);st.live=false;say('<h2>This game hit a problem</h2><p>Head back to the library and try again.</p><a class="btn" href="#/games">Back to games</a>')};
 const count=n=>{if(!n)return begin();say(`<div class="big">${n}</div>`);beep(500);st.cd=setTimeout(()=>count(n-1),600)};
 const begin=async()=>{say('');box.innerHTML='';const run=st.run=runner();run.onerr=fail;
  try{const m=await import(`../games/${id}.js`);if(cur!==st)return run.destroy();
   t0=Date.now();st.live=true;$('#sc').textContent='0';
   m.default({box,run,sfx:beep,score:n=>{$('#sc').textContent=n},over:(sc,ex)=>{st.live=false;const rec=finish(id,sc,ex);beep(rec?880:200,.25);$('#bs').textContent=best(id);
    say(`<h2>Game over</h2><p class="big">${sc}</p><p>${rec?'New personal record!':'Best '+best(id)}</p><button class="btn" data-a="restart">Play again</button> <a class="btn ghost" href="#/game/${id}">Exit</a>`)}}).start()}
  catch(e){fail(e)}};
 st.go=()=>count(3);
 st.restart=()=>{clearTimeout(st.cd);st.run?.destroy();st.live=false;st.paused=false;count(3)};
 st.pause=()=>{if(!st.live)return;st.paused=!st.paused;if(st.paused){st.run.pause();say('<h2>Paused</h2><button class="btn" data-a="pause">Resume</button>')}else{say('');st.run.resume()}};
 st.fs=()=>document.fullscreenElement?document.exitFullscreen():$('.play').requestFullscreen?.().catch(()=>{});
 st.snd=()=>{db().settings.sound=!db().settings.sound;S.save();toast('Sound '+(db().settings.sound?'on':'off'))};
 say(`<h2>How to play</h2><p>${g.how}</p><button class="btn" data-a="go">Start</button>`)};

function route(){stopGame();const[,p='home',arg]=location.hash.split('/');const pg=V[p]?p:'home';
 document.body.classList.toggle('playing',pg==='play');
 document.querySelectorAll('#nav a').forEach(a=>{const on=a.dataset.p===(pg==='game'||pg==='play'?'games':pg);on?a.setAttribute('aria-current','page'):a.removeAttribute('aria-current')});
 try{V[pg](arg)}catch(e){console.error(e);view.innerHTML='<p class="empty">Something went wrong. <a href="#/home">Go home</a></p>'}
 if(pg!=='play')scrollTo(0,0)}
addEventListener('hashchange',route);

document.addEventListener('click',e=>{const t=e.target.closest('[data-a]');if(!t)return;const a=t.dataset.a,id=t.dataset.id,d=db();
 if(a==='fav'){const i=d.favs.indexOf(id);i<0?d.favs.push(id):d.favs.splice(i,1);S.save();beep(i<0?700:300);check({});
  document.querySelectorAll(`.fav[data-id="${id}"]`).forEach(b=>{b.classList.toggle('on',i<0);b.setAttribute('aria-pressed',i<0)});if(location.hash==='#/favs')route()}
 else if(a==='cat'){cat=id;V.games()}
 else if(a==='tog'){d.settings[id]=t.checked;S.save();applyMotion()}
 else if(a==='name'){d.player.name=($('#nm').value.trim().slice(0,16))||'Saii';S.save();toast('Name saved')}
 else if(a==='wipe'){if(!confirm(id==='all'?'Erase ALL progress, scores and settings?':'Clear '+id+'?'))return;
  if(id==='all')S.reset();else d[id]=[];S.save();applyMotion();route()}
 else if(cur&&cur[a])cur[a]()});
document.addEventListener('input',e=>{if(e.target.id==='q'){q=e.target.value;fill()}});
document.addEventListener('change',e=>{if(e.target.id==='so'){sort=e.target.value;fill()}});
document.addEventListener('visibilitychange',()=>{if(document.hidden&&cur?.live&&!cur.paused)cur.pause()});
document.addEventListener('keydown',e=>{if(cur&&(e.key==='Escape'||e.key==='p')&&e.target.tagName!=='INPUT')cur.pause()});
const applyMotion=()=>document.body.classList.toggle('calm',!db().settings.motion);
applyMotion();route();
if('serviceWorker' in navigator)addEventListener('load',()=>navigator.serviceWorker.register('service-worker.js').catch(()=>{}));
