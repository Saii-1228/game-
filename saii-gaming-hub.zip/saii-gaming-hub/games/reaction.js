export default function({box,run,score,over,sfx}){
 const R=5,times=[];let state='idle',t0=0,tok=0;
 const pad=document.createElement('button');pad.className='react';box.append(pad);
 const set=(s,t)=>{pad.dataset.s=s;pad.textContent=t};
 const arm=()=>{state='wait';const my=++tok;set('wait',`Round ${times.length+1} of ${R}. Wait for green…`);
  run.after(1000+Math.random()*2500,()=>{if(state!=='wait'||my!==tok)return;state='go';t0=performance.now();set('go','TAP NOW!')})};
 run.on(pad,'pointerdown',e=>{e.preventDefault();
  if(state==='wait'){state='idle';tok++;sfx(180,.2,'sawtooth');set('early','Too early! Tap to retry this round')}
  else if(state==='go'){const ms=Math.round(performance.now()-t0);times.push(ms);score(ms);sfx(700);
   if(times.length===R){state='done';const avg=Math.round(times.reduce((a,b)=>a+b)/R);
    set('idle',`Average ${avg} ms`);run.after(900,()=>over(Math.max(0,Math.round(1500-avg*3)),{avg}))}
   else{state='idle';set('idle',`${ms} ms. Tap for the next round`)}}
  else if(state==='idle')arm()});
 return{start(){score(0);set('idle','Tap to begin')}};
}
