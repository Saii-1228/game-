import {swipe,dpad} from '../js/engine.js';
export default function({box,run,score,over,sfx}){
 const N=20,S=20,cv=document.createElement('canvas');cv.width=cv.height=N*S;cv.className='cv';
 cv.setAttribute('aria-label','Snake board');box.append(cv);const g=cv.getContext('2d');
 let sn,dir,nd,food,acc,pts,spd;
 const place=()=>{do food={x:Math.random()*N|0,y:Math.random()*N|0};while(sn.some(s=>s.x===food.x&&s.y===food.y))};
 const turn=(x,y)=>{if(x!==-dir.x||y!==-dir.y)nd={x,y}};
 const K={ArrowUp:[0,-1],w:[0,-1],ArrowDown:[0,1],s:[0,1],ArrowLeft:[-1,0],a:[-1,0],ArrowRight:[1,0],d:[1,0]};
 run.on(document,'keydown',e=>{const k=K[e.key.length===1?e.key.toLowerCase():e.key];if(k){e.preventDefault();turn(...k)}});
 swipe(cv,run,turn);dpad(box,run,turn);
 const step=()=>{dir=nd;const h={x:sn[0].x+dir.x,y:sn[0].y+dir.y};
  const eat=h.x===food.x&&h.y===food.y,body=eat?sn:sn.slice(0,-1);
  if(h.x<0||h.y<0||h.x>=N||h.y>=N||body.some(s=>s.x===h.x&&s.y===h.y)){run.stop();sfx(180,.3,'sawtooth');over(pts);return}
  sn.unshift(h);
  if(eat){pts+=10;score(pts);spd=Math.max(.06,spd-.004);place();sfx(660)}else sn.pop()};
 const draw=()=>{g.fillStyle='#050714';g.fillRect(0,0,N*S,N*S);
  g.fillStyle='#ff3d81';g.beginPath();g.arc(food.x*S+S/2,food.y*S+S/2,S/2-3,0,7);g.fill();
  sn.forEach((s,i)=>{g.fillStyle=i?'#22e6ff':'#3dffa2';g.fillRect(s.x*S+1,s.y*S+1,S-2,S-2)})};
 return{start(){sn=[{x:10,y:10},{x:9,y:10},{x:8,y:10}];dir=nd={x:1,y:0};pts=0;spd=.13;acc=0;place();score(0);
  run.loop(dt=>{acc+=dt;while(acc>=spd){acc-=spd;step();if(!sn)return}},draw)}};
}
