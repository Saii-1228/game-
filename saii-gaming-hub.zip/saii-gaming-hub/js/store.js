// One versioned object under one key. Falls back to memory if localStorage fails.
const K='saiiGamingHub';
const def=()=>({v:1,player:{name:'Saii',xp:0},settings:{sound:true,motion:true},favs:[],history:[],scores:{},plays:{},ach:[],total:0,time:0});
function load(){const d=def();try{const x=JSON.parse(localStorage.getItem(K));if(x&&x.v===1)for(const k in d)if(typeof x[k]===typeof d[k]&&Array.isArray(x[k])===Array.isArray(d[k]))d[k]=x[k]}catch{}
 if(typeof d.player.name!=='string'||typeof d.player.xp!=='number')d.player=def().player;return d}
let db=load();
export const get=()=>db;
export function save(){try{localStorage.setItem(K,JSON.stringify(db))}catch{}}
export function reset(){db=def();save()}
