export default function({box,run,over,sfx}){
 const W=[[0,1,2],[3,4,5],[6,7,8],[0,3,6],[1,4,7],[2,5,8],[0,4,8],[2,4,6]],b=Array(9).fill('');
 const el=document.createElement('div');el.className='board3';
 const cells=b.map((_,i)=>{const c=document.createElement('button');c.setAttribute('aria-label','Square '+(i+1));run.on(c,'click',()=>play(i));el.append(c);return c});
 const info=document.createElement('p');info.className='hint';info.textContent='Your turn: X';box.append(el,info);
 let busy=false;
 const win=p=>W.some(l=>l.every(i=>b[i]===p));
 const put=(i,p)=>{b[i]=p;cells[i].textContent=p;cells[i].disabled=true;sfx(p==='X'?520:330)};
 const end=(m,sc,won)=>{info.textContent=m;busy=true;run.after(900,()=>over(sc,{won}))};
 const ai=()=>{const e=b.map((v,i)=>v?-1:i).filter(i=>i>=0);
  const find=p=>e.find(i=>{b[i]=p;const w=win(p);b[i]='';return w});
  let m=find('O');if(m==null)m=find('X');if(m==null&&!b[4])m=4;if(m==null)m=e[Math.random()*e.length|0];
  put(m,'O');if(win('O'))end('You lost',0,false);else if(e.length===1)end('Draw',30,false);else{busy=false;info.textContent='Your turn: X'}};
 const play=i=>{if(busy||b[i])return;put(i,'X');
  if(win('X'))return end('You win!',100,true);
  if(b.every(Boolean))return end('Draw',30,false);
  busy=true;run.after(350,ai)};
 return{start(){}};
}
