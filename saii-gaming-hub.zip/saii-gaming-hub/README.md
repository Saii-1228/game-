# SAII GAMING HUB
Play. Compete. Level Up. A static browser games hub by Saii (github.com/saii-1228). No build step, no backend.

## Run locally
ES modules need a server: `python3 -m http.server 8000` then open http://localhost:8000

## Deploy to GitHub Pages
1. Create repo `saii-gaming-hub` under saii-1228, upload every file in this folder (keep the folder layout).
2. Settings > Pages > Deploy from branch > `main` / root.
3. Open https://saii-1228.github.io/saii-gaming-hub/ (all paths are relative, so the sub-path works).
4. After changing files, bump `V` in service-worker.js so installed copies refresh.

## Add a game
1. Add an entry to `js/games.js` (id, title, cat, diff, time, ico, hue, tags, desc, how).
2. Create `games/<id>.js` with `export default function({box,run,score,over,sfx}){...; return {start(){}}}`.
   Use `run.on` for listeners, `run.after` for timers, `run.loop(update(dt),draw)` for animation: all are cleaned up on exit/restart.
   Call `score(n)` to update the HUD and `over(finalScore,{...extra})` when finished.
3. Add the file to the list in `service-worker.js`.

## Scoring, XP, storage
`over()` calls `finish()` in app.js: increments plays, saves best score, adds XP (10 + min(50, score/10)), checks achievements (+50 XP each).
Level N+1 needs 25*N*(N+3) XP (100, 250, 450, ...). Everything lives in ONE versioned object, localStorage key `saiiGamingHub` (`v:1`), validated on load; falls back to memory if storage is blocked. Scores are local to the device, never labelled global.

## Test checklist (per game)
Starts after countdown, keyboard + touch controls, score updates, game over, restart, pause (button, Esc, tab switch), exit, best score saved, XP up, replay 5 times, no console errors, no page scroll while playing, usable at 320px width.

## Not yet built
More games (Breakout, Pong, Flappy, 2048, Minesweeper...), PNG icons (192/512) for full Android install prompt, music, backend leaderboard (replace `finish()`/score reads in app.js).
