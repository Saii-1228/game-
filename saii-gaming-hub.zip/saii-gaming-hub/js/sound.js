import {get} from './store.js';
let ac;
export function beep(f=440,d=.08,t='square'){
 if(!get().settings.sound)return;
 try{ac=ac||new (window.AudioContext||window.webkitAudioContext)();const o=ac.createOscillator(),g=ac.createGain();
  o.type=t;o.frequency.value=f;g.gain.value=.04;o.connect(g);g.connect(ac.destination);o.start();o.stop(ac.currentTime+d)}catch{}
}
