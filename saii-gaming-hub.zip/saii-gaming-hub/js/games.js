// Game registry. To add a game: add an entry here, create games/<id>.js, add it to service-worker.js.
export const CATS=['Arcade','Classic','Memory','Reflex'];
export const GAMES=[
{id:'snake',title:'Neon Snake',cat:'Arcade',diff:'Medium',time:'3 min',ico:'🐍',hue:170,tags:'classic endless grow',desc:'Eat glowing orbs, grow longer and never touch your own tail. Speed rises as you score.',how:'Arrow keys or WASD. On phones, swipe the board or use the on-screen pad.'},
{id:'ttt',title:'Tic Tac Toe',cat:'Classic',diff:'Easy',time:'1 min',ico:'❌',hue:280,tags:'strategy versus computer',desc:'Beat the computer. A win scores 100, a draw scores 30.',how:'Click or tap a square to place your X.'},
{id:'memory',title:'Memory Match',cat:'Memory',diff:'Easy',time:'2 min',ico:'🧠',hue:320,tags:'cards pairs focus',desc:'Flip cards and find all 8 pairs in as few moves as you can.',how:'Click or tap two cards at a time.'},
{id:'reaction',title:'Reaction Test',cat:'Reflex',diff:'Medium',time:'1 min',ico:'⚡',hue:50,tags:'speed timing tap',desc:'Five rounds. Tap the moment the pad turns green. Faster is a higher score.',how:'Click or tap the pad when it turns green.'}
];
