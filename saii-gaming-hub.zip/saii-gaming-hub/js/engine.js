// Per-game runner: owns the RAF loop, listeners and timers, and removes all of them on destroy().
export function runner(){
 const offs=[],tms=[];let raf=0,last=0,on=false,was=false,paused=false,U,D;
 const tick=t=>{if(!on)return;const dt=Math.min(.05,(t-last)/1000);last=t;
  try{U(dt);D()}catch(e){r.stop();r.onerr&&r.onerr(e);return}
  if(on)raf=requestAnimationFrame(tick)};
 const go=()=>{on=true;last=performance.now();raf=requestAnimationFrame(tick)};
 const r={onerr:null,
  on(el,ev,fn,o){el.addEventListener(ev,fn,o);offs.push(()=>el.removeEventListener(ev,fn,o))},
  loop(u,d){U=u;D=d;go()},
  stop(){on=false;was=false;cancelAnimationFrame(raf)},
  pause(){paused=true;was=on;on=false;cancelAnimationFrame(raf)},
  resume(){paused=false;if(was)go()},
  after(ms,fn){tms.push(setTimeout(()=>paused?r.after(100,fn):fn(),ms))},
  destroy(){r.stop();offs.forEach(f=>f());tms.forEach(clearTimeout);offs.length=tms.length=0}};
 return r;
}
export function swipe(el,r,cb){let sx=0,sy=0;
 r.on(el,'touchstart',e=>{sx=e.touches[0].clientX;sy=e.touches[0].clientY},{passive:true});
 r.on(el,'touchend',e=>{const t=e.changedTouches[0],dx=t.clientX-sx,dy=t.clientY-sy;
  if(Math.max(Math.abs(dx),Math.abs(dy))<24)return;Math.abs(dx)>Math.abs(dy)?cb(Math.sign(dx),0):cb(0,Math.sign(dy))},{passive:true});
}
export function dpad(box,r,cb){const d=document.createElement('div');d.className='dpad';
 [['▲',0,-1],['◀',-1,0],['▶',1,0],['▼',0,1]].forEach(([l,x,y],i)=>{const b=document.createElement('button');
  b.textContent=l;b.setAttribute('aria-label','Move '+['up','left','right','down'][i]);b.style.gridArea='abcd'[i];
  r.on(b,'pointerdown',e=>{e.preventDefault();cb(x,y)});d.append(b)});
 box.append(d);
}
